# PanaHub Motion Graphics — 9:16 (1080×1920)

## Scenes

| File | Scene | Length | Background |
|---|---|---|---|
| `PanaHub - Intro (9x16).dc.html` | Intro | 5s | White |
| `PanaHub - Lower Third (9x16).dc.html` | Lower third — Yonayka / Owner | 5s | **Transparent** |
| `PanaHub - Follow (9x16).dc.html` | "and follow PanaHub across the USA" | 5s | White |
| `PanaHub - Outro (9x16).dc.html` | Outro — logo, @panamahubusa, platforms | 5s | White |
| `PanaHub Motion Package (9x16).dc.html` | All four, back to back | 20s | White |

## How to open
Keep the folder structure as-is and open any `.dc.html` in Chrome.
`support.js`, `animations-v2.jsx`, `panahub-vertical-scenes.jsx`, and
`assets/panahub-logo.png` must stay alongside them.

## Getting video files for Premiere
Open a scene in the app preview and use the video export in the timeline
panel — one MP4 per scene. Export the lower third with a transparent
background so it keys over your footage.

## Editing the text
All copy lives in `panahub-vertical-scenes.jsx`:
- Lower third name/title — `LowerThird()`, currently "Yonayka" / "Owner"
- Handle — `@panamahubusa` in `Follow()` and `Outro()`
- State chips — `FOLLOW_PLACES` array

## Brand
`brand/panahub-logo.svg` — vector, transparent background (stars + wordmark)
`brand/panahub-stars.svg` — vector, transparent, stars only (icon / bug use)
`brand/panahub-logo.png` — 1800×1800 raster, white background
`brand/panahub-facebook-cover.png` — Facebook cover

Colors: blue `#0057B8` · red `#D72638` · ink `#1F2937`
Type: Poppins — 600/700 for the wordmark and headlines

## About the SVGs
The stars are true vector paths — scale them to any size.
The wordmark is live text set in Poppins 600, so Poppins must be
installed (or use the PNG) for it to render correctly. If you need the
wordmark as outlines, open the SVG in Illustrator and run
Type > Create Outlines.
