const { useScene, Easing, clamp } = window;

const W = 1080, H = 1920;
const BLUE = '#0057B8', RED = '#D72638', INK = '#1F2937', PAPER = '#FFFFFF', LINE = '#E5E7EB', MUTED = '#6B7280';
const FONT = '"Poppins", Futura, "Century Gothic", sans-serif';
const STAR = 'polygon(50% 0%,63.5% 36.5%,100% 36.5%,69% 59%,79.5% 95%,50% 73%,20.5% 95%,31% 59%,0% 36.5%,36.5% 36.5%)';

function span(local, start, dur) { return clamp((local - start) / dur, 0, 1); }
const ease = (p) => Easing.easeOutCubic(clamp(p, 0, 1));
const easeIB = (p) => Easing.easeInCubic(clamp(p, 0, 1));

function Star({ size, color, style }) {
  return <div style={{ width: size, height: size, background: color, clipPath: STAR, ...style }} />;
}

// Two-star lockup. `spread` 0 = fully apart, 1 = final overlap.
function StarPair({ size, spread, blueOpacity = 1, redOpacity = 1, blueRot = 0, redRot = 0 }) {
  const overlap = size * 0.02;
  const gap = (1 - spread) * size * 0.55;
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Star size={size} color={BLUE} style={{
        marginRight: -overlap + gap, opacity: blueOpacity,
        transform: `rotate(${blueRot}deg)`, zIndex: 2, position: 'relative',
      }} />
      <Star size={size} color={RED} style={{ opacity: redOpacity, transform: `rotate(${redRot}deg)` }} />
    </div>
  );
}

// ── Scene 1: INTRO ───────────────────────────────────────────────────────
function Intro() {
  const { localTime, dur } = useScene();
  const blueP = ease(span(localTime, 0.1, 0.6));
  const redP = ease(span(localTime, 0.35, 0.6));
  const joinP = ease(span(localTime, 0.85, 0.7));
  const wordP = ease(span(localTime, 1.35, 0.7));
  const ruleP = ease(span(localTime, 1.8, 0.6));
  const tagP = ease(span(localTime, 2.0, 0.7));
  const exitP = easeIB(span(localTime, dur - 0.6, 0.6));

  const size = 190;
  const settle = 0.92 + 0.08 * joinP;

  return (
    <div style={{
      position: 'absolute', inset: 0, background: PAPER, overflow: 'hidden', opacity: 1 - exitP,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 46, padding: '0 70px',
    }}>
      <div style={{ transform: `scale(${settle})` }}>
        <StarPair
          size={size}
          spread={joinP}
          blueOpacity={blueP}
          redOpacity={redP}
          blueRot={(1 - blueP) * -22}
          redRot={(1 - redP) * 22}
        />
      </div>

      <div style={{
        fontFamily: FONT, fontWeight: 600, fontSize: 104, color: INK, letterSpacing: '-0.005em',
        opacity: wordP, transform: `translateY(${(1 - wordP) * 22}px)`,
      }}>PanaHub</div>

      <div style={{ width: 200 * ruleP, height: 5, background: RED, borderRadius: 5 }} />

      <div style={{
        fontFamily: FONT, fontWeight: 500, fontSize: 30, color: MUTED, textAlign: 'center', lineHeight: 1.5,
        letterSpacing: '0.04em', opacity: tagP, transform: `translateY(${(1 - tagP) * 12}px)`,
      }}>Todo lo panameño en un solo lugar<br />
        <span style={{ fontSize: 26, color: '#9CA3AF' }}>Everything Panamanian. One place.</span></div>
    </div>
  );
}

// ── Scene 2: LOWER THIRD (transparent — keys over footage) ───────────────
function LowerThird() {
  const { localTime, dur } = useScene();
  const wipeP = ease(span(localTime, 0.25, 0.65));
  const nameP = ease(span(localTime, 0.55, 0.6));
  const roleP = ease(span(localTime, 0.75, 0.6));
  const barP = ease(span(localTime, 0.45, 0.7));
  const outP = easeIB(span(localTime, dur - 0.7, 0.6));
  const live = clamp(1 - outP, 0, 1);

  const cardW = 860 * wipeP;

  return (
    <div style={{ position: 'absolute', inset: 0, background: 'transparent', overflow: 'hidden' }}>
      {/* corner bug */}
      <div style={{
        position: 'absolute', top: 70, left: 60, opacity: live * ease(span(localTime, 0.1, 0.5)),
        display: 'flex', alignItems: 'center', gap: 14, background: 'rgba(255,255,255,0.95)',
        borderRadius: 16, padding: '14px 22px', boxShadow: '0 12px 34px rgba(11,17,32,0.24)',
      }}>
        <div style={{ position: 'relative', width: 62, height: 31, overflow: 'hidden', flexShrink: 0 }}>
          <img src="./assets/panahub-logo.png" alt="PanaHub" style={{
            position: 'absolute', width: 98, height: 98, objectFit: 'contain',
            left: -17.6, top: -21.6,
          }} />
        </div>
        <div style={{ fontFamily: FONT, fontWeight: 600, fontSize: 30, color: INK, letterSpacing: '-0.005em' }}>PanaHub</div>
      </div>

      {/* lower third */}
      <div style={{ position: 'absolute', left: 60, bottom: 300, opacity: live }}>
        <div style={{ display: 'flex', alignItems: 'stretch', overflow: 'hidden', borderRadius: 18, width: cardW, boxShadow: '0 18px 44px rgba(11,17,32,0.28)' }}>
          <div style={{ width: 14 * barP, background: RED, flexShrink: 0 }} />
          <div style={{ background: 'rgba(255,255,255,0.97)', padding: '30px 40px', minWidth: 0, flex: 1 }}>
            <div style={{
              fontFamily: FONT, fontWeight: 800, fontSize: 60, color: INK, whiteSpace: 'nowrap',
              opacity: nameP, transform: `translateX(${(1 - nameP) * -26}px)`,
            }}>Yonayka</div>
            <div style={{
              fontFamily: FONT, fontWeight: 600, fontSize: 30, color: BLUE, letterSpacing: '0.06em',
              textTransform: 'uppercase', marginTop: 8, whiteSpace: 'nowrap',
              opacity: roleP, transform: `translateX(${(1 - roleP) * -20}px)`,
            }}>Owner</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Scene 3: OUTRO ───────────────────────────────────────────────────────
function Outro() {
  const { localTime, dur } = useScene();
  const markP = ease(span(localTime, 0.15, 0.65));
  const ruleP = ease(span(localTime, 0.95, 0.55));
  const ctaP = ease(span(localTime, 1.2, 0.6));
  const socialP = ease(span(localTime, 1.55, 0.6));
  const exitP = easeIB(span(localTime, dur - 0.6, 0.6));

  return (
    <div style={{
      position: 'absolute', inset: 0, background: PAPER, overflow: 'hidden', opacity: 1 - exitP,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 38, padding: '0 70px',
    }}>
      <div style={{ opacity: markP, transform: `scale(${0.9 + 0.1 * markP})` }}>
        <div style={{ position: 'relative', width: 620, height: 341, overflow: 'hidden' }}>
          <img src="./assets/panahub-logo.png" alt="PanaHub" style={{
            position: 'absolute', left: 0, top: -124, width: 620, height: 620, objectFit: 'contain', display: 'block',
          }} />
        </div>
      </div>

      <div style={{ width: 170 * ruleP, height: 5, background: RED, borderRadius: 5 }} />

      <div style={{
        opacity: ctaP, transform: `translateY(${(1 - ctaP) * 14}px)`, background: BLUE, color: PAPER,
        fontFamily: FONT, fontWeight: 700, fontSize: 34, letterSpacing: '0.02em',
        padding: '22px 48px', borderRadius: 999, boxShadow: '0 18px 40px rgba(0,87,184,0.3)',
      }}>@panamahubusa</div>

      <div style={{
        fontFamily: FONT, fontWeight: 600, fontSize: 27, color: MUTED, letterSpacing: '0.08em',
        opacity: socialP, transform: `translateY(${(1 - socialP) * 10}px)`, textAlign: 'center', lineHeight: 1.6,
      }}>Instagram · Facebook · TikTok</div>
    </div>
  );
}


// ── Scene 4: FOLLOW — "and follow PanaHub across the USA" ───────────────
const FOLLOW_PLACES = ['New York', 'Florida', 'Georgia', 'Texas', 'California', 'Washington, DC'];

function Follow() {
  const { localTime, dur } = useScene();
  const markP = ease(span(localTime, 0.1, 0.55));
  const l1P = ease(span(localTime, 0.45, 0.6));
  const l2P = ease(span(localTime, 0.7, 0.6));
  const ruleP = ease(span(localTime, 1.05, 0.5));
  const handleP = ease(span(localTime, 2.6, 0.6));
  const exitP = easeIB(span(localTime, dur - 0.6, 0.6));

  // star sweeps left→right behind the headline
  const sweepRaw = ease(span(localTime, 0.35, 2.4));
  const sweepX = -140 + sweepRaw * (1220);
  const sweepY = 60 * Math.sin(sweepRaw * Math.PI);

  return (
    <div style={{
      position: 'absolute', inset: 0, background: PAPER, overflow: 'hidden', opacity: 1 - exitP,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 34, padding: '0 80px',
    }}>
      {/* travelling star */}
      <div style={{
        position: 'absolute', left: sweepX, top: 470 + sweepY, opacity: 0.14 * (1 - Math.abs(sweepRaw - 0.5) * 0.6),
        transform: `rotate(${sweepRaw * 220}deg)`,
      }}>
        <Star size={230} color={BLUE} />
      </div>

      <div style={{ position: 'relative', width: 250, height: 86, overflow: 'hidden', opacity: markP,
        transform: `scale(${0.92 + 0.08 * markP})`, flexShrink: 0 }}>
        <img src="./assets/panahub-logo.png" alt="PanaHub" style={{
          position: 'absolute', left: 0, top: -50, width: 250, height: 250, objectFit: 'contain',
        }} />
      </div>

      <div style={{ position: 'relative', textAlign: 'center' }}>
        <div style={{
          fontFamily: FONT, fontWeight: 500, fontSize: 44, color: MUTED, letterSpacing: '0.02em',
          opacity: l1P, transform: `translateY(${(1 - l1P) * 16}px)`,
        }}>and follow PanaHub</div>
        <div style={{
          fontFamily: FONT, fontWeight: 700, fontSize: 72, color: INK, letterSpacing: '-0.01em', marginTop: 14,
          whiteSpace: 'nowrap', opacity: l2P, transform: `translateY(${(1 - l2P) * 20}px)`,
        }}>across the <span style={{ color: BLUE }}>U</span><span style={{ color: RED }}>S</span><span style={{ color: BLUE }}>A</span></div>
      </div>

      <div style={{ width: 190 * ruleP, height: 5, background: RED, borderRadius: 5 }} />

      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 14, maxWidth: 860 }}>
        {FOLLOW_PLACES.map((place, i) => {
          const p = ease(span(localTime, 1.25 + i * 0.16, 0.5));
          return (
            <div key={place} style={{
              fontFamily: FONT, fontWeight: 600, fontSize: 30, color: BLUE, background: '#EAF0FF',
              borderRadius: 999, padding: '14px 30px', opacity: p,
              transform: `translateY(${(1 - p) * 14}px) scale(${0.94 + 0.06 * p})`, whiteSpace: 'nowrap',
            }}>{place}</div>
          );
        })}
      </div>

      <div style={{
        fontFamily: FONT, fontWeight: 700, fontSize: 34, color: INK, letterSpacing: '0.04em',
        opacity: handleP, transform: `translateY(${(1 - handleP) * 12}px)`, textAlign: 'center', lineHeight: 1.55,
      }}>@panamahubusa<br />
        <span style={{ fontWeight: 500, fontSize: 24, color: '#9CA3AF', letterSpacing: '0.02em' }}>Instagram · Facebook · TikTok</span></div>
    </div>
  );
}

window.PhFollow = Follow;

window.PhIntro = Intro;
window.PhLowerThird = LowerThird;
window.PhOutro = Outro;

function AppPanaHubV() {
  React.useEffect(() => {
    try {
      if (!window.__panahubVCleared) { localStorage.removeItem('animstage:t'); window.__panahubVCleared = true; }
    } catch (e) {}
  }, []);
  return (
    <div style={{ width: '100%', height: '100%' }}>
      <window.SceneStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={PAPER}>
        {{ Intro, LowerThird, Follow, Outro }}
      </window.SceneStage>
    </div>
  );
}
window.AppPanaHubV = AppPanaHubV;

function makeSingleApp(name, dur, comp, bg, key) {
  return function AppSingle() {
    React.useEffect(() => {
      try {
        const k = '__panahubSingle_' + key;
        if (!window[k]) { localStorage.removeItem('animstage:t'); window[k] = true; }
      } catch (e) {}
    }, []);
    const scenesJson = JSON.stringify([{ name, dur }]);
    return (
      <div style={{ width: '100%', height: '100%' }}>
        <window.SceneStage width={W} height={H} scenes={scenesJson} playback={'{"mode":"times","count":1}'} bg={bg}>
          {{ [name]: comp }}
        </window.SceneStage>
      </div>
    );
  };
}
window.AppPhIntro = makeSingleApp('Intro', 5, Intro, PAPER, 'intro');
window.AppPhLowerThird = makeSingleApp('LowerThird', 5, LowerThird, 'transparent', 'lt');
window.AppPhFollow = makeSingleApp('Follow', 5, Follow, PAPER, 'follow');
window.AppPhOutro = makeSingleApp('Outro', 5, Outro, PAPER, 'outro');
