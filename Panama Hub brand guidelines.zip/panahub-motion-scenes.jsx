const { useScene, Easing, clamp, SceneStage, useTweaks, TweaksPanel, TweakToggle } = window;

// ── persistent stage ─────────────────────────────────────────────────
const W = 1280, H = 720;
const BLUE = '#0057B8', RED = '#D72638', LBLUE = '#0a63c9', DBLUE = '#004a9e';
const BADGE = { cx: W / 2, cy: 280, r: 100 };

// three motion helpers — nothing animates outside these
const MOTION = {
  enter: (p) => Easing.easeOutCubic(clamp(p, 0, 1)),
  pop: (p) => Easing.easeOutBack(clamp(p, 0, 1)),
  drift: (t) => Math.sin(t * 0.6),
};

function span(local, start, dur) {
  return clamp((local - start) / dur, 0, 1);
}

function Background({ globalT }) {
  const dx1 = MOTION.drift(globalT) * 18;
  const dy1 = MOTION.drift(globalT * 0.8 + 1) * 14;
  const dx2 = MOTION.drift(globalT * 0.7 + 2) * -16;
  const dy2 = MOTION.drift(globalT * 0.5 + 0.5) * 12;
  return (
    <>
      <rect x={0} y={0} width={W} height={H} fill={BLUE} />
      <circle cx={W - 140 + dx1} cy={-60 + dy1} r={280} fill={LBLUE} opacity={0.55} />
      <circle cx={-40 + dx2} cy={H + 60 + dy2} r={260} fill={DBLUE} opacity={0.6} />
      <rect x={0} y={H - 8} width={W / 2} height={8} fill="#FFFFFF" />
      <rect x={W / 2} y={H - 8} width={W / 2} height={8} fill={RED} />
    </>
  );
}

function StarPath(cx, cy, r) {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const ang = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? r : r * 0.4;
    pts.push(`${cx + Math.cos(ang) * rad},${cy + Math.sin(ang) * rad}`);
  }
  return pts.join(' ');
}

// badgeP: 0-1 pop-in of the whole badge; starP: 0-1 pop-in of the star; nodeP: 0-1 pop-in of the red node
function LogoMark({ badgeP, starP, nodeP, breathe = 0 }) {
  const s = MOTION.pop(badgeP) * (1 + breathe);
  const ss = MOTION.pop(starP);
  const ns = MOTION.pop(nodeP);
  return (
    <g style={{ opacity: badgeP > 0 ? 1 : 0 }} transform={`translate(${BADGE.cx} ${BADGE.cy}) scale(${s})`}>
      <circle cx={0} cy={0} r={BADGE.r} fill="#FFFFFF" />
      <g transform={`scale(${ss})`}>
        <polygon points={StarPath(0, 0, BADGE.r * 0.55)} fill={BLUE} />
      </g>
      <g style={{ opacity: nodeP > 0 ? 1 : 0 }} transform={`translate(${BADGE.r * 0.68} ${BADGE.r * 0.68}) scale(${ns})`}>
        <circle cx={0} cy={0} r={20} fill={RED} stroke="#FFFFFF" strokeWidth={5} />
      </g>
    </g>
  );
}

function Wordmark({ p }) {
  const e = MOTION.enter(p);
  const y = 440 + (1 - e) * 16;
  return (
    <text x={W / 2} y={y} textAnchor="middle" fontFamily="Poppins" fontWeight="800" fontSize="72"
      fill="#FFFFFF" opacity={e} style={{ letterSpacing: '-1px' }}>PanaHub</text>
  );
}

function Tagline({ p }) {
  const e = MOTION.enter(p);
  const y = 486 + (1 - e) * 12;
  return (
    <text x={W / 2} y={y} textAnchor="middle" fontFamily="Poppins" fontStyle="italic" fontSize="26"
      fill="#d8e8ff" opacity={e}>Panam&#225; vive aqu&#237;. &middot; Panama lives here.</text>
  );
}

function MarkAssemble() {
  const { localTime, index } = useScene();
  const globalT = index * 2.5 + localTime;
  const badgeP = span(localTime, 0.1, 0.7);
  const starP = span(localTime, 0.45, 0.7);
  const nodeP = span(localTime, 0.95, 0.55);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%">
      <Background globalT={globalT} />
      <LogoMark badgeP={badgeP} starP={starP} nodeP={nodeP} />
      <Wordmark p={0} />
      <Tagline p={0} />
    </svg>
  );
}

function WordmarkReveal() {
  const { localTime, index } = useScene();
  const globalT = index * 2.5 + localTime;
  const breathe = Math.sin(localTime * 2.4) * 0.012;
  const wordP = span(localTime, 0.05, 0.55);
  const tagP = span(localTime, 0.5, 0.6);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="100%">
      <Background globalT={globalT} />
      <LogoMark badgeP={1} starP={1} nodeP={1} breathe={breathe} />
      <Wordmark p={wordP} />
      <Tagline p={tagP} />
    </svg>
  );
}

window.MarkAssemble = MarkAssemble;
window.WordmarkReveal = WordmarkReveal;

function App() {
  const [t, setTweak] = useTweaks(window.PANAHUB_TWEAKS);
  return (
    <div style={{ width: '100%', height: '100%' }}>
      <SceneStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={BLUE}>
        {{ MarkAssemble, WordmarkReveal }}
      </SceneStage>
      <TweaksPanel>
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}
window.App = App;
