const { useScene, Easing, clamp } = window;

const W = 1080, H = 1920;
const NAVY = '#1E1A8C', RED = '#C9291F', INK = '#1F2937', PAPER = '#FFFFFF', LINE = '#D8DBE6';
const FONT = 'Futura, "Century Gothic", "Poppins", sans-serif';

function span(local, start, dur) { return clamp((local - start) / dur, 0, 1); }
const ease = (p) => Easing.easeOutCubic(clamp(p, 0, 1));
const easeIB = (p) => Easing.easeInCubic(clamp(p, 0, 1));

function Stripe({ w, h, label }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: 12, overflow: 'hidden', position: 'relative',
      background: 'repeating-linear-gradient(135deg, #2b3145 0 22px, #232838 22px 44px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ fontFamily: 'JetBrains Mono, ui-monospace, monospace', fontSize: 18, letterSpacing: '0.08em',
        color: 'rgba(255,255,255,0.55)', textTransform: 'uppercase' }}>{label}</div>
    </div>
  );
}

// ── Scene 1: INTRO (stacked) ─────────────────────────────────────────────
function Intro() {
  const { localTime, dur } = useScene();
  const soloP = ease(span(localTime, 0.05, 0.75));
  const moveP = ease(span(localTime, 0.75, 0.75));
  const dividerP = ease(span(localTime, 1.15, 0.5));
  const withP = ease(span(localTime, 1.3, 0.55));
  const longP = ease(span(localTime, 1.55, 0.75));
  const exitP = easeIB(span(localTime, dur - 0.55, 0.55));
  const groupOpacity = 1 - exitP;

  const soloScale = 1.5, slotScale = 1;
  const scale = soloScale + (slotScale - soloScale) * moveP;
  const cy = 960 + (740 - 960) * moveP;

  return (
    <div style={{ position: 'absolute', inset: 0, background: PAPER, overflow: 'hidden', opacity: groupOpacity }}>
      <div style={{ position: 'absolute', left: 540, top: cy, transform: `translate(-50%,-50%) scale(${scale})`,
        opacity: soloP, width: 200, height: 266 }}>
        <img src="./assets/vsgc-logo.png" alt="Virginia Space Grant Consortium"
          style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
      </div>

      <div style={{ position: 'absolute', left: 540, top: 960, transform: 'translate(-50%,-50%)',
        width: 220 * dividerP, height: 2, background: LINE }} />

      <div style={{ position: 'absolute', left: 540, top: 960, transform: `translate(-50%,-50%) translateY(${(1 - withP) * 10}px)`,
        opacity: withP, fontFamily: FONT, fontWeight: 600, fontSize: 22, letterSpacing: '0.2em',
        textTransform: 'uppercase', color: '#8A8F9E', whiteSpace: 'nowrap' }}>In Partnership With</div>

      <div style={{ position: 'absolute', left: 540, top: 1160, transform: `translate(-50%,-50%) scale(${0.85 + 0.15 * ease(longP)})`,
        opacity: ease(longP), width: 200, height: 200, borderRadius: 20, background: PAPER,
        border: `1px solid ${LINE}`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 18px 40px rgba(20,20,40,0.08)' }}>
        <img src="./assets/longbow-logo.jpg" alt="Longbow" style={{ width: '72%', height: '72%', objectFit: 'contain' }} />
      </div>
    </div>
  );
}

// ── Scene 2: ON-SCREEN LOWER-THIRD TEMPLATE ─────────────────────────────
function LowerThird() {
  const { localTime, dur } = useScene();
  const barInP = ease(span(localTime, 0.3, 0.6));
  const barOutP = easeIB(span(localTime, dur - 0.7, 0.6));
  const barP = clamp(barInP - barOutP, 0, 1);
  const cornerP = ease(span(localTime, 0.15, 0.5)) * (1 - easeIB(span(localTime, dur - 0.4, 0.4)));
  const barY = 40 + (0 - 40) * barP;

  return (
    <div style={{ position: 'absolute', inset: 0, background: 'transparent', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 64, left: 32, opacity: cornerP,
        transform: `scale(${0.9 + 0.1 * cornerP})`, display: 'flex', alignItems: 'center', gap: 14,
        background: 'rgba(255,255,255,0.94)', borderRadius: 14, padding: '12px 18px', boxShadow: '0 10px 30px rgba(0,0,0,0.25)' }}>
        <img src="./assets/vsgc-logo.png" style={{ width: 28, height: 37, objectFit: 'contain' }} />
        <div style={{ width: 1, height: 24, background: LINE }} />
        <img src="./assets/longbow-logo.jpg" style={{ width: 32, height: 32, objectFit: 'contain', borderRadius: 6 }} />
      </div>

      <div style={{ position: 'absolute', left: 32, bottom: 160 + barY, opacity: barP,
        display: 'flex', flexDirection: 'column', width: 1016, borderRadius: 14, overflow: 'hidden',
        boxShadow: '0 20px 50px rgba(0,0,0,0.35)' }}>
        <div style={{ height: 8, background: RED }} />
        <div style={{ background: NAVY, display: 'flex', alignItems: 'center', gap: 18, padding: '22px 26px' }}>
          <div style={{ width: 78, height: 78, borderRadius: 10, background: PAPER, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <img src="./assets/vsgc-logo.png" style={{ width: '70%', height: '70%', objectFit: 'contain' }} />
          </div>
          <div style={{ width: 78, height: 78, borderRadius: 10, background: PAPER, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <img src="./assets/longbow-logo.jpg" style={{ width: '78%', height: '78%', objectFit: 'contain' }} />
          </div>
        </div>
        <div style={{ background: PAPER, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '22px 26px', gap: 6 }}>
          <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: 26, color: INK }}>Virginia Space Grant Consortium &amp; Longbow</div>
          <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 18, letterSpacing: '0.06em', textTransform: 'uppercase', color: RED }}>Official Program Partner</div>
        </div>
      </div>
    </div>
  );
}

// ── Scene: POSITION TITLE CARD ──────────────────────────────────────────
function TitleCard() {
  const { localTime, dur } = useScene();
  const barInP = ease(span(localTime, 0.25, 0.55));
  const barOutP = easeIB(span(localTime, dur - 0.6, 0.5));
  const barP = clamp(barInP - barOutP, 0, 1);
  const nameY = 30 * (1 - barP);
  const cornerP = ease(span(localTime, 0.1, 0.4)) * (1 - easeIB(span(localTime, dur - 0.4, 0.4)));

  return (
    <div style={{ position: 'absolute', inset: 0, background: 'transparent', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 64, left: 32, opacity: cornerP,
        transform: `scale(${0.9 + 0.1 * cornerP})`, display: 'flex', alignItems: 'center', gap: 14,
        background: 'rgba(255,255,255,0.94)', borderRadius: 14, padding: '12px 18px', boxShadow: '0 10px 30px rgba(0,0,0,0.25)' }}>
        <img src="./assets/vsgc-logo.png" style={{ width: 28, height: 37, objectFit: 'contain' }} />
        <div style={{ width: 1, height: 24, background: LINE }} />
        <img src="./assets/longbow-logo.jpg" style={{ width: 32, height: 32, objectFit: 'contain', borderRadius: 6 }} />
      </div>

      <div style={{ position: 'absolute', left: 60, bottom: 220, right: 60, opacity: barP,
        transform: `translateY(${nameY}px)`, display: 'flex', flexDirection: 'column' }}>
        <div style={{ width: 84 * barP, height: 5, background: RED, borderRadius: 4, marginBottom: 16 }} />
        <div style={{ background: 'rgba(18,19,26,0.82)', borderLeft: `6px solid ${RED}`, padding: '22px 30px',
          display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 38, color: PAPER }}>Dr. Jane Alvarado</div>
          <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 20, letterSpacing: '0.04em',
            textTransform: 'uppercase', color: '#C9CDE0' }}>Program Director &middot; Virginia Space Grant Consortium</div>
        </div>
      </div>
    </div>
  );
}

// ── Scene: TRANSITION BUMPER (vertical wipe) ─────────────────────────────
function Transition() {
  const { localTime, dur } = useScene();
  const wipeInP = ease(span(localTime, 0, 0.4));
  const wipeOutP = easeIB(span(localTime, dur - 0.4, 0.4));
  const coverP = clamp(wipeInP - wipeOutP, 0, 1);
  const markP = ease(span(localTime, 0.3, 0.35)) * (1 - easeIB(span(localTime, dur - 0.45, 0.3)));

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, background: NAVY,
        transform: `scaleY(${coverP})`, transformOrigin: 'top center' }} />
      <div style={{ position: 'absolute', inset: 0, background: RED, opacity: 0.9,
        transform: `scaleY(${coverP})`, transformOrigin: 'top center', clipPath: 'inset(96% 0 0 0)' }} />
      <div style={{ position: 'absolute', left: '50%', top: '50%', transform: `translate(-50%,-50%) scale(${0.85 + 0.15 * markP})`,
        opacity: markP, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18 }}>
        <img src="./assets/vsgc-logo.png" style={{ width: 64, height: 85, objectFit: 'contain' }} />
        <div style={{ width: 56, height: 1, background: 'rgba(255,255,255,0.4)' }} />
        <div style={{ width: 74, height: 74, borderRadius: 12, background: PAPER, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img src="./assets/longbow-logo.jpg" style={{ width: '74%', height: '74%', objectFit: 'contain' }} />
        </div>
      </div>
    </div>
  );
}

// ── Scene 3: OUTRO ───────────────────────────────────────────────────────
function Outro() {
  const { localTime, dur } = useScene();
  const lockupP = ease(span(localTime, 0.15, 0.7));
  const thanksP = ease(span(localTime, 0.65, 0.75));
  const lineP = ease(span(localTime, 1.15, 0.6));
  const tagP = ease(span(localTime, 1.35, 0.6));
  const ctaP = ease(span(localTime, 1.65, 0.55));
  const exitP = easeIB(span(localTime, dur - 0.6, 0.6));
  const opacity = 1 - exitP;

  return (
    <div style={{ position: 'absolute', inset: 0, background: PAPER, overflow: 'hidden', opacity,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 34, padding: '0 60px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22, opacity: lockupP,
        transform: `translateY(${(1 - lockupP) * 14}px)` }}>
        <img src="./assets/vsgc-logo.png" style={{ width: 84, height: 112, objectFit: 'contain' }} />
        <div style={{ width: 60, height: 1, background: LINE }} />
        <div style={{ width: 84, height: 84, borderRadius: 14, border: `1px solid ${LINE}`, display: 'flex',
          alignItems: 'center', justifyContent: 'center' }}>
          <img src="./assets/longbow-logo.jpg" style={{ width: '74%', height: '74%', objectFit: 'contain' }} />
        </div>
      </div>

      <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 68, color: NAVY, textAlign: 'center',
        opacity: thanksP, transform: `translateY(${(1 - thanksP) * 18}px) scale(${0.94 + 0.06 * thanksP})` }}>Thank You</div>

      <div style={{ width: 120 * lineP, height: 4, background: RED, borderRadius: 4 }} />

      <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 22, color: '#6B7280', textAlign: 'center',
        opacity: tagP, transform: `translateY(${(1 - tagP) * 10}px)`, letterSpacing: '0.02em' }}>
        Presented in partnership by VSGC &amp; Longbow
      </div>

      <div style={{ opacity: ctaP, transform: `translateY(${(1 - ctaP) * 10}px)`,
        background: RED, color: PAPER, fontFamily: FONT, fontWeight: 700, fontSize: 20,
        letterSpacing: '0.03em', padding: '16px 34px', borderRadius: 999, textAlign: 'center',
        boxShadow: '0 14px 30px rgba(201,41,31,0.3)' }}>Learn More at vsgc.odu.edu</div>
    </div>
  );
}

window.IntroV = Intro;
window.LowerThirdV = LowerThird;
window.TitleCardV = TitleCard;
window.TransitionV = Transition;
window.OutroV = Outro;

function AppVertical() {
  React.useEffect(() => {
    try {
      if (!window.__vsgcLongbowVCleared) {
        localStorage.removeItem('animstage:t');
        window.__vsgcLongbowVCleared = true;
      }
    } catch (e) {}
  }, []);
  return (
    <div style={{ width: '100%', height: '100%' }}>
      <window.SceneStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={PAPER}>
        {{ Intro, LowerThird, TitleCard, Transition, Outro }}
      </window.SceneStage>
    </div>
  );
}
window.AppVertical = AppVertical;


// ── Single-scene export wrappers (one MP4 per piece in Premiere) ────────
function makeSingleApp(name, dur, comp, bg, key) {
  return function AppSingle() {
    React.useEffect(() => {
      try {
        const k = '__vsgcSingleClearedV_' + key;
        if (!window[k]) { localStorage.removeItem('animstage:t'); window[k] = true; }
      } catch (e) {}
    }, []);
    const scenesJson = JSON.stringify([{ name, dur }]);
    return (
      <div style={{ width: '100%', height: '100%' }}>
        <window.SceneStage width={W} height={H} scenes={scenesJson} playback={'{"mode":"times","count":1}'} bg={bg}>
          {{ [name]: comp }}
        </window.SceneStage>
      </div>
    );
  };
}
window.AppIntroV = makeSingleApp('Intro', 5, Intro, PAPER, 'introv');
window.AppLowerThirdV = makeSingleApp('LowerThird', 5, LowerThird, 'transparent', 'ltv');
window.AppTitleCardV = makeSingleApp('TitleCard', 4, TitleCard, 'transparent', 'tcv');
window.AppTransitionV = makeSingleApp('Transition', 2, Transition, 'transparent', 'trv');
window.AppOutroV = makeSingleApp('Outro', 5, Outro, PAPER, 'outrov');
